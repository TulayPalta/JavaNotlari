package _26_polymorphism;

import java.util.ArrayList;
import java.util.List;

public class _3_parametric {

  /*
  Parametric Polymorphism Java’da diğer bir adıyla Generic
  olarak bilinmektedir. Bu konu başlığı altında çok detayına inmeden
  basitçe anlatarak bir örnek vermeye çalışacağım. Java’da bir alan
  String bir değer alarak yine String bir değer dönerken, yine aynı
  şekilde integer bir değer alarak yine integer bir değer dönebilir.
  Basitçe bir örnek üzerinden anlatmak gerekirse;

  Örneği ParametricDemo ve ParametricTest class larında
   */

}
