package _27_exceptionHandling;

public class AttemptException extends Exception {

    public AttemptException(String message){
        super(message);
    }


}
