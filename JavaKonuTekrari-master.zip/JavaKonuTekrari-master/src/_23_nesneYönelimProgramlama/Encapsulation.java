package _23_nesneYönelimProgramlama;

public class Encapsulation {

    //Kapsülleme (Encapsulation)

    /*
    Oluşturduğumuz bir sınıftaki değişkenlerin setter ve getter
    metotları kullanılarak ve bu setter ve getter metotlarına
    erişim belirleyicilerle belli sınıflardan erişim sağlanmasına
    izin vermek belli sınıflardan erişim sağlanmasına izin vermemek
    gibi kontroller Kapsülleme ile mümkündür. Kapsülleme yazılımcıya
    oluşturduğu sınıftaki değişkenlerin erişimlerini kontrol yetkisi verir.
     */


}
