package _19_arraysSinifi;

import java.util.Arrays;

public class _toStringMethodu {
    public static void main(String[] args)
    {

        int[] liste = {1, 4, 99, 2, 5, -3, 6, 2,-49,52};//Dizi'mizi oluşturuyoruz

        // dizimizi direk konsola yazdırabilmek için Arrays.toString() kullanılır
        System.out.println(Arrays.toString(liste));
    }
}
