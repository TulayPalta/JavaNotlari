package _21_NesneVeSinifYapisi;

public class Sinif {
    /*
    Sınıf
    Java Nesne ve Sınıf Yapısı’nda “Nesneler sınıflardan oluşur”
    demiştik, o halde öncelikle sınıf yapısı nasıl oluşur ona bakalım;
     */



    /*

    public degiskenTuru degiskenTuru;
    //constructor
    Sinif() {
    }
    //constructor
    Sinif(degiskenTuru yeniDegiskenTuru) {
        degiskenTuru = yeniDegiskenTuru;
    }
    //metot
    void metotAdi() {
    }

     */



}
