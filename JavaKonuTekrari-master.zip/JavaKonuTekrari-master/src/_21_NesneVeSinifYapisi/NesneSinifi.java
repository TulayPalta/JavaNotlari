package _21_NesneVeSinifYapisi;

public class NesneSinifi {

    /*
    Java Nesne ve Sınıf Yapısında nesnelerin sınıflardan oluştuğunu
    daha önce söylemiştim. Sınıf yapısını gördüğümüze göre artık
    sınıflardan nasıl nesne oluşturulduğunu görebiliriz.
    En basit ve genel yöntemle;
     */

    NesneSinifi nesne = new NesneSinifi();

    /*
    şeklinde bir tanımlama ile "nesne" nesnesi oluşturulabilir.
    Yine daha iyi anlaşılması için Araba sınıfımız üzerinden
    devam edelim.
    Öncelikle Araba sınıfımızda biraz değişiklik yapalım ve
    araba nesnemizi oluşturalım.
     */
}
