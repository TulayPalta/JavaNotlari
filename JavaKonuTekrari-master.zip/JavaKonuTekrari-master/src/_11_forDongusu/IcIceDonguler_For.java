package _11_forDongusu;

public class IcIceDonguler_For {
    public static void main(String[] args) {

        //nested loop
        for(int i = 0; i<10; i++) {
            System.out.println("i: " + i);
            for(int j=10; j>0; j--) {
                System.out.println("i: " + i + " j: " + j);
            }
        }

        //Sonsuz For Döngüsü

        /*
        For Döngüsü ile sonsuz döngü oluşturmak istenirse
        aşağıdaki gibi bir kod yazmak yeterli olacaktır;
         */

        /*
        //sonsuz dongu
        for( ;1; ) {

        }
         */

    }
}
