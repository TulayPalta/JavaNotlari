package _1_veriTipleriVeDegiskenler;

public class Double {
    public static void main(String[] args) {

        /*
        DOUBLE: double veri tipi 64 bitlik büyüklüğe sahiptir
        ve 4.9×10^-324 ile 1.8×10^308 arasında bir değer tanımlanabilir.
         Kod geliştirirken double anahtar kelimesi ile tanımlama yapılır.
         */

        double doubleDeger = 34.5;
        System.out.println(doubleDeger);
    }
}
