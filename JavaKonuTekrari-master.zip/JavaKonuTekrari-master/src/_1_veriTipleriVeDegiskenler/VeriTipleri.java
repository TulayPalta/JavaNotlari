package _1_veriTipleriVeDegiskenler;

public class VeriTipleri {
    public static void main(String[] args) {

        byte byteDeger = 4;
        short shortDeger = 7;
        int integerDeger = 234;
        long longDeger = 12332;

        float floatDeger = 34.5f;
        double doubleDeger = 345.2;

        char charDeger1 = 65;
        char charDeger2 = 'A';

        boolean dogruDeger = true;
        boolean yanlisDeger = false;

        System.out.println("Byte Değer: " + byteDeger);
        System.out.println("Short Değer: " + shortDeger);
        System.out.println("Integer Değer: " + integerDeger);
        System.out.println("Long Değer: " + longDeger);

        System.out.println("Float Deger: " + floatDeger);
        System.out.println("Double Deger: " + doubleDeger);

        System.out.println("Char Deger 1: " + charDeger1);
        System.out.println("Char Deger 2: " + charDeger2);

        System.out.println("Boolean Dogru: " + dogruDeger);
        System.out.println("Boolean Yanlis: " + yanlisDeger);


    }
}
