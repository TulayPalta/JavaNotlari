package _1_veriTipleriVeDegiskenler;

public class Short {
    public static void main(String[] args) {

        /*
        SHORT: Büyüklüğü 16 bit olan short veri tipi -32768 ile
         +32767 arasında bir değer alabilir. Kod geliştirirken
         short anahtar kelimesi ile tanımlama yapılır.
         */
        short shortDeger =64;

        /*
        Yukarıda görmüş olduğunuz kod satırında short veri tipiyle değeri
        64 olan “shortDeger” değişken adıyla bir tanımlama yapılmıştır.
        Eğer değer olarak -32769 veya 32678 verseydik geliştirme anında
         hata ile karşılaşacaktık.
         */
    }
}
