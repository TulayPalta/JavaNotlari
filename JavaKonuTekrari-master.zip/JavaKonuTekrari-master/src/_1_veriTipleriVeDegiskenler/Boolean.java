package _1_veriTipleriVeDegiskenler;

public class Boolean {
    public static void main(String[] args) {


    /*
        BOOLEAN: Java mantıksal değerlerini saklamak için boolean
        veri tipi kullanılmaktadır. Boolean veri tipi true ve false
        olmak üzere iki farklı değer alabilmektedir. boolean veri tipi
        genellikle koşul belirtirken veya bir döngüde kullanılabilir.
        Kod geliştirirken boolean anahtar kelimesi ile tanımlama yapılır.
         */

        boolean booleanDogru = true;
        System.out.println(booleanDogru);
        boolean booleanYanlis = false;
        System.out.println(booleanYanlis);
    }
}
