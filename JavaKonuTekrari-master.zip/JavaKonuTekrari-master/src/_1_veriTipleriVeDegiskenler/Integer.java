package _1_veriTipleriVeDegiskenler;

public class Integer {
    public static void main(String[] args) {

        /*
        INTEGER: En çok kullanılan veri tipidir. 32 bitlik veri tipi,
         -2.147.483.648 ile 2.147.483.647 arasında bir değer alabilir.
          Kod geliştirirken int anahtar kelimesi ile tanımlama yapılır.
         */

        int integerDeger = 75;
        System.out.println(integerDeger);

        /*
        Yukarıda görmüş olduğunuz kod satırında integer veri tipiyle değeri
        75 olan, “integerDeger” değişken adıyla bir tanımlama yapılmıştır.
        Eğer yukarıda belirttiğimiz değer aralığından daha küçük veya daha
        büyük bir tanımlama yapılırsa geliştirme anında hata ile karşılaşılır.
         */

    }
}
