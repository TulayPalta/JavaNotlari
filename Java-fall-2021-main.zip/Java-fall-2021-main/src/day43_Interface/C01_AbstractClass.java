package day43_Interface;

public abstract class C01_AbstractClass {
	
	// abstract class'lar CLASS olduklari icin constructor'a sahiptirler
	// ancak abstract class'lardan obje OLUSTURULAMAZ
	
	C01_AbstractClass(){
		
	}
	
	public static void main(String[] args) {
		
		
		
		// C01_AbstractClass obj1 =new C01_AbstractClass();
		
	}

}
