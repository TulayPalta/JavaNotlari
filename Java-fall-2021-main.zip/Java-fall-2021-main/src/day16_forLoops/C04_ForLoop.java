package day16_forLoops;

public class C04_ForLoop {

	public static void main(String[] args) {
		// Soru 3)  100�den baslayarak 50�ye(dahil) kadar olan sayilari 
		//			aralarinda virgul olarak ayni satirda yazdirin
		
		for (int i = 100; i > 50; i--) {
			System.out.print(i + ", ");
		}
		System.out.println(50);

	}

}
