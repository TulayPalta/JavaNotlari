package day16_forLoops;

public class C02_ForLoop {

	public static void main(String[] args) {
		// Soru 1 ) Ekrana 10 kez �Java guzeldir� yazdirin
		/*
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		System.out.println("Java guzeldir");
		*/
		
		for (int i = 1; i <= 10; i++) {
			System.out.println(i + ". Java guzeldir");
		}


	}

}
