package day34_accessDeneme;

import day34_accessModifier_encapsulation.C05;

public class C03_GetterBaskaPackagedan {

	public static void main(String[] args) {
		
		C05 obj007 = new C05();
		
		System.out.println(obj007.getAsgariMaas());

	}

}
