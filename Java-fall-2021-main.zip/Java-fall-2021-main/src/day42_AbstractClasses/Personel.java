package day42_AbstractClasses;

public class Personel {


	public void statu() {
		System.out.println("Sirkete alinan herkes bizim personelimizdir .. imza:Persdonel");
	}

}
