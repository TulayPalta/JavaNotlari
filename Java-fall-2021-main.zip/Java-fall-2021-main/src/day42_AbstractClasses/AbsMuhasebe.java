package day42_AbstractClasses;

public abstract class AbsMuhasebe extends AbsPersonel{
	
	public abstract void maas();

}
