package day42_AbstractClasses;

public class Isci extends Muhasebe{
	
	public void mesai() {
		System.out.println("Her iscinin mesai saatleri belli olmali. Imza Isci");
	}

}
