package day42_AbstractClasses;

public class Muhasebe extends Personel{
	
	public void maas() {
		System.out.println("Sirketteki her calisanin maasi olmali. imza: Muhasebe");
	}

}
