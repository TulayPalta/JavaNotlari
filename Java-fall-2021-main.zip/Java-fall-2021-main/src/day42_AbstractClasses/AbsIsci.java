package day42_AbstractClasses;

public abstract class AbsIsci extends AbsMuhasebe{
	
	public abstract void mesai(); 

}
