package day37_Inheritance;

public class Araba {
	
	protected int tekerSayisi;
	protected boolean calisiyorMu=true;
	
	public void method1() {
		System.out.println("Araba class'indan method1 calisti");
	}

}
