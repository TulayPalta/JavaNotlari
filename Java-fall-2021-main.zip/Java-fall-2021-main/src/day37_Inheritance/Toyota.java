package day37_Inheritance;

public class Toyota extends Araba{

	protected boolean pahaliMi;
	protected String uretimYeri="Japonya";
	
	
	public void method1() {
		System.out.println("Toyota class'indan method1 calisti");
	}
	public void method2() {
		System.out.println("Toyota class'indan method2 calisti");
	}
	
}
