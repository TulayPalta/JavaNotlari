package day34_accessModifier_encapsulation;

public class C07_Getter {

	public static void main(String[] args) {
		
		C05 obj216 = new C05();
		System.out.println(obj216.getAsgariMaas());

	}

}
