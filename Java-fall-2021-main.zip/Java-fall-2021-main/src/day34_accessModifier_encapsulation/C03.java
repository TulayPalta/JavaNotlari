package day34_accessModifier_encapsulation;

public class C03 {
	
	public String isim="Ali Can";
	public int maas=10000;

	public static void main(String[] args) {
		

	}

}
