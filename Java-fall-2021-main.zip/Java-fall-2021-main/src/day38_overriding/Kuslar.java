package day38_overriding;

public class Kuslar extends Animals {

	public static void main(String[] args) {
		

	}
	
	public void hareket() {
		System.out.println("Kuslar Ucarak hareket eder");
	}
	
	
	public void solunum() {
		System.out.println("Kuslar akcigerleriyle nefes alir");
	}

}
