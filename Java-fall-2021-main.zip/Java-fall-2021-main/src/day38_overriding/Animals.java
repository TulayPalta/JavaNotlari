package day38_overriding;

public class Animals {

	public static void main(String[] args) {
		

	}
	// Overridden
	
	public void hareket() {
		System.out.println("Tum hayvanlar hareket eder");
	}
	
	public void beslenme() {
		System.out.println("Tum hayvanlar beslenir");
	}
	
	public void solunum() {
		System.out.println("Tum hayvanlar nefes alir");
	}

}
