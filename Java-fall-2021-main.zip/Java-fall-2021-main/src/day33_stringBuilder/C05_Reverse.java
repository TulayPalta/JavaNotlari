package day33_stringBuilder;

public class C05_Reverse {

	public static void main(String[] args) {
		// verilen bir cumleyi tersten yazdiralim
		
		StringBuilder sb = new StringBuilder("Java ne kadar kolay");
		
		sb.reverse();
		
		System.out.println(sb);
		

	}

}
