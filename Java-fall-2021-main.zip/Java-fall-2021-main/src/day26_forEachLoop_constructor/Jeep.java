package day26_forEachLoop_constructor;

public class Jeep {

	
		int ilanNo=1001;
		String marka;
		String model;
		int yil=2001;
		int fiyat=10000;
		
		public void hiz(int hiz) {
			System.out.println("araba saatte " + hiz + " km yapar");
		}
		
		public void yakit(String yakit) {
			System.out.println("Araba yakit olarak " + yakit + " kullanir");
		}

	

}
