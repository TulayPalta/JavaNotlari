package day41_errors_garbageCollector;

public class C01_Final {
	
	final static double pi=3.14;

	public static void main(String[] args) {
		
		System.out.println(pi);

	}

}
